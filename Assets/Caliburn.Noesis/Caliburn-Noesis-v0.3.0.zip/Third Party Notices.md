This package contains third-party software components governed by the license(s) indicated below:

Component Name: Caliburn.Micro

License Type: "MIT"

[Caliburn.Micro License](https://github.com/Caliburn-Micro/Caliburn.Micro/blob/master/License.txt)