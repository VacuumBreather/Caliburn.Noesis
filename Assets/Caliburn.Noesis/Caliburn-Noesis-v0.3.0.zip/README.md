# Caliburn.Noesis

Caliburn.Noesis is a port of the small, yet powerful Caliburn.Micro framework, designed for building graphical user interfaces. This version is designed for the NoesisGUI XAML platform in Unity. With strong support for MVVM and other proven UI patterns, Caliburn.Noesis enables you to build your game UI quickly without sacrificing code quality or testability.

Install in the Unity Package Manager via https://github.com/VacuumBreather/Caliburn.Noesis.git?path=Assets/Caliburn.Noesis